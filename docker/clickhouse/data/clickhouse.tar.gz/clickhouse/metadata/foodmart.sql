ATTACH DATABASE foodmart
ENGINE = Ordinary
