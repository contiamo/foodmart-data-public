ATTACH TABLE agg_c_10_sales_fact_1997
(
    month_of_year Int16, 
    quarter String, 
    the_year Int16, 
    store_sales Float32, 
    store_cost Float32, 
    unit_sales Float32, 
    customer_count Int32, 
    fact_count Int32
)
ENGINE = TinyLog
