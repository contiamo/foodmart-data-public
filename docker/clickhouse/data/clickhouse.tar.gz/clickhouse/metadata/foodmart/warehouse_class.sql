ATTACH TABLE warehouse_class
(
    warehouse_class_id Int32, 
    description Nullable(String)
)
ENGINE = TinyLog
