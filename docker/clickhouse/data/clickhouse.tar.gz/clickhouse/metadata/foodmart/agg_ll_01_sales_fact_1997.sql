ATTACH TABLE agg_ll_01_sales_fact_1997
(
    product_id Int32, 
    time_id Int32, 
    customer_id Int32, 
    store_sales Float32, 
    store_cost Float32, 
    unit_sales Float32, 
    fact_count Int32
)
ENGINE = TinyLog
