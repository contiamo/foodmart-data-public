ATTACH TABLE agg_l_03_sales_fact_1997
(
    time_id Int32, 
    customer_id Int32, 
    store_sales Float32, 
    store_cost Float32, 
    unit_sales Float32, 
    fact_count Int32
)
ENGINE = TinyLog
