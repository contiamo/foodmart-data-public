ATTACH TABLE agg_l_05_sales_fact_1997
(
    product_id Int32, 
    customer_id Int32, 
    promotion_id Int32, 
    store_id Int32, 
    store_sales Float32, 
    store_cost Float32, 
    unit_sales Float32, 
    fact_count Int32
)
ENGINE = TinyLog
