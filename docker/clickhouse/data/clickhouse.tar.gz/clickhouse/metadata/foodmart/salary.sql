ATTACH TABLE salary
(
    pay_date DateTime, 
    employee_id Int32, 
    department_id Int32, 
    currency_id Int32, 
    salary_paid Float32, 
    overtime_paid Float32, 
    vacation_accrued Float64, 
    vacation_used Float64
)
ENGINE = TinyLog
