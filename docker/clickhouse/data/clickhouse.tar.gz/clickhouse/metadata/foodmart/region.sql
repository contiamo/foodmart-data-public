ATTACH TABLE region
(
    region_id Int32, 
    sales_city Nullable(String), 
    sales_state_province Nullable(String), 
    sales_district Nullable(String), 
    sales_region Nullable(String), 
    sales_country Nullable(String), 
    sales_district_id Nullable(Int32)
)
ENGINE = TinyLog
