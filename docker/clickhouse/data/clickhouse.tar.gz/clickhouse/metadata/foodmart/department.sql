ATTACH TABLE department
(
    department_id Int32, 
    department_description String
)
ENGINE = TinyLog
