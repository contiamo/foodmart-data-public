ATTACH TABLE store
(
    store_id Int32, 
    store_type Nullable(String), 
    region_id Nullable(Int32), 
    store_name Nullable(String), 
    store_number Nullable(Int32), 
    store_street_address Nullable(String), 
    store_city Nullable(String), 
    store_state Nullable(String), 
    store_postal_code Nullable(String), 
    store_country Nullable(String), 
    store_manager Nullable(String), 
    store_phone Nullable(String), 
    store_fax Nullable(String), 
    first_opened_date Nullable(DateTime), 
    last_remodel_date Nullable(DateTime), 
    store_sqft Nullable(Int32), 
    grocery_sqft Nullable(Int32), 
    frozen_sqft Nullable(Int32), 
    meat_sqft Nullable(Int32), 
    coffee_bar Nullable(UInt8), 
    video_store Nullable(UInt8), 
    salad_bar Nullable(UInt8), 
    prepared_food Nullable(UInt8), 
    florist Nullable(UInt8)
)
ENGINE = TinyLog
