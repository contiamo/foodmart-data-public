ATTACH TABLE employee_closure
(
    employee_id Int32, 
    supervisor_id Int32, 
    distance Nullable(Int32)
)
ENGINE = TinyLog
