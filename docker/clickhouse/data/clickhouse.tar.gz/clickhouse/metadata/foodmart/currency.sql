ATTACH TABLE currency
(
    currency_id Int32, 
    date Date, 
    currency String, 
    conversion_ratio Float32
)
ENGINE = TinyLog
