ATTACH TABLE position
(
    position_id Int32, 
    position_title String, 
    pay_type String, 
    min_scale Float32, 
    max_scale Float32, 
    management_role String
)
ENGINE = TinyLog
