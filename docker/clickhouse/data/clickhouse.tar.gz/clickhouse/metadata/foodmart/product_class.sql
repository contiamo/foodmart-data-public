ATTACH TABLE product_class
(
    product_class_id Int32, 
    product_subcategory Nullable(String), 
    product_category Nullable(String), 
    product_department Nullable(String), 
    product_family Nullable(String)
)
ENGINE = TinyLog
