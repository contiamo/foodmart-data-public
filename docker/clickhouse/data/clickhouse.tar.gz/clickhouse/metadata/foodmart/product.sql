ATTACH TABLE product
(
    product_class_id Int32, 
    product_id Int32, 
    brand_name Nullable(String), 
    product_name String, 
    SKU Int64, 
    SRP Nullable(Float32), 
    gross_weight Nullable(Float64), 
    net_weight Nullable(Float64), 
    recyclable_package Nullable(UInt8), 
    low_fat Nullable(UInt8), 
    units_per_case Nullable(Int16), 
    cases_per_pallet Nullable(Int16), 
    shelf_width Nullable(Float64), 
    shelf_height Nullable(Float64), 
    shelf_depth Nullable(Float64)
)
ENGINE = TinyLog
