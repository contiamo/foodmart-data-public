ATTACH TABLE agg_g_ms_pcat_sales_fact_1997
(
    gender String, 
    marital_status String, 
    product_family Nullable(String), 
    product_department Nullable(String), 
    product_category Nullable(String), 
    month_of_year Int16, 
    quarter String, 
    the_year Int16, 
    store_sales Float32, 
    store_cost Float32, 
    unit_sales Float32, 
    customer_count Int32, 
    fact_count Int32
)
ENGINE = TinyLog
