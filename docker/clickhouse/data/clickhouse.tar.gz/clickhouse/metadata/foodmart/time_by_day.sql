ATTACH TABLE time_by_day
(
    time_id Int32, 
    the_date Nullable(DateTime), 
    the_day Nullable(String), 
    the_month Nullable(String), 
    the_year Nullable(Int16), 
    day_of_month Nullable(Int16), 
    week_of_year Nullable(Int32), 
    month_of_year Nullable(Int16), 
    quarter Nullable(String), 
    fiscal_period Nullable(String)
)
ENGINE = TinyLog
