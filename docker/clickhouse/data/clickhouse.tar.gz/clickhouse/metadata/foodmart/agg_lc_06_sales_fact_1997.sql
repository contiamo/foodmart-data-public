ATTACH TABLE agg_lc_06_sales_fact_1997
(
    time_id Int32, 
    city String, 
    state_province String, 
    country String, 
    store_sales Float32, 
    store_cost Float32, 
    unit_sales Float32, 
    fact_count Int32
)
ENGINE = TinyLog
