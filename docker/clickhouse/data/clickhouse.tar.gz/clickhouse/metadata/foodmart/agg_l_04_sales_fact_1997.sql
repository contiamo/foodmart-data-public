ATTACH TABLE agg_l_04_sales_fact_1997
(
    time_id Int32, 
    store_sales Float32, 
    store_cost Float32, 
    unit_sales Float32, 
    customer_count Int32, 
    fact_count Int32
)
ENGINE = TinyLog
