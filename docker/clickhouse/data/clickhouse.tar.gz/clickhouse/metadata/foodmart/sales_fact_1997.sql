ATTACH TABLE sales_fact_1997
(
    product_id Int32, 
    time_id Int32, 
    customer_id Int32, 
    promotion_id Int32, 
    store_id Int32, 
    store_sales Float32, 
    store_cost Float32, 
    unit_sales Float32
)
ENGINE = TinyLog
