ATTACH TABLE warehouse
(
    warehouse_id Int32, 
    warehouse_class_id Nullable(Int32), 
    stores_id Nullable(Int32), 
    warehouse_name Nullable(String), 
    wa_address1 Nullable(String), 
    wa_address2 Nullable(String), 
    wa_address3 Nullable(String), 
    wa_address4 Nullable(String), 
    warehouse_city Nullable(String), 
    warehouse_state_province Nullable(String), 
    warehouse_postal_code Nullable(String), 
    warehouse_country Nullable(String), 
    warehouse_owner_name Nullable(String), 
    warehouse_phone Nullable(String), 
    warehouse_fax Nullable(String)
)
ENGINE = TinyLog
