ATTACH TABLE reserve_employee
(
    employee_id Int32, 
    full_name String, 
    first_name String, 
    last_name String, 
    position_id Nullable(Int32), 
    position_title Nullable(String), 
    store_id Int32, 
    department_id Int32, 
    birth_date DateTime, 
    hire_date Nullable(DateTime), 
    end_date Nullable(DateTime), 
    salary Float32, 
    supervisor_id Nullable(Int32), 
    education_level String, 
    marital_status String, 
    gender String
)
ENGINE = TinyLog
