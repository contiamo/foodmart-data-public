ATTACH TABLE agg_c_special_sales_fact_1997
(
    product_id Int32, 
    promotion_id Int32, 
    customer_id Int32, 
    store_id Int32, 
    time_month Int16, 
    time_quarter String, 
    time_year Int16, 
    store_sales_sum Float32, 
    store_cost_sum Float32, 
    unit_sales_sum Float32, 
    fact_count Int32
)
ENGINE = TinyLog
