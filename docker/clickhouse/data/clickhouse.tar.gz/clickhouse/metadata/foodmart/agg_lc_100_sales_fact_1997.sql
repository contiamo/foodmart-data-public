ATTACH TABLE agg_lc_100_sales_fact_1997
(
    product_id Int32, 
    customer_id Int32, 
    quarter String, 
    the_year Int16, 
    store_sales Float32, 
    store_cost Float32, 
    unit_sales Float32, 
    fact_count Int32
)
ENGINE = TinyLog
