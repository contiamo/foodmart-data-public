ATTACH TABLE account
(
    account_id Int32, 
    account_parent Nullable(Int32), 
    account_description Nullable(String), 
    account_type String, 
    account_rollup String, 
    Custom_Members Nullable(String)
)
ENGINE = TinyLog
