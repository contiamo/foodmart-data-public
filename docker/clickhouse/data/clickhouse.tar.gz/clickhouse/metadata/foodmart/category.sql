ATTACH TABLE category
(
    category_id String, 
    category_parent Nullable(String), 
    category_description String, 
    category_rollup Nullable(String)
)
ENGINE = TinyLog
