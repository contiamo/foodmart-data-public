ATTACH TABLE inventory_fact_1998
(
    product_id Int32, 
    time_id Nullable(Int32), 
    warehouse_id Nullable(Int32), 
    store_id Nullable(Int32), 
    units_ordered Nullable(Int32), 
    units_shipped Nullable(Int32), 
    warehouse_sales Nullable(Float32), 
    warehouse_cost Nullable(Float32), 
    supply_time Nullable(Int16), 
    store_invoice Nullable(Float32)
)
ENGINE = TinyLog
