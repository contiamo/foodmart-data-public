ATTACH TABLE days
(
    day Int32, 
    week_day String
)
ENGINE = TinyLog
