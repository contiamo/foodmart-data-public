ATTACH TABLE expense_fact
(
    store_id Int32, 
    account_id Int32, 
    exp_date DateTime, 
    time_id Int32, 
    category_id String, 
    currency_id Int32, 
    amount Float32
)
ENGINE = TinyLog
