ATTACH TABLE promotion
(
    promotion_id Int32, 
    promotion_district_id Nullable(Int32), 
    promotion_name Nullable(String), 
    media_type Nullable(String), 
    cost Nullable(Float32), 
    start_date Nullable(DateTime), 
    end_date Nullable(DateTime)
)
ENGINE = TinyLog
